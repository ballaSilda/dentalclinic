export class EnumTipos  {

    public static LETRAS_E_ESPACO = '[a-zA-Z ]';
    public static EMAIL = '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$';
    public static NUMERICO = '^[0-9]*$';
}
