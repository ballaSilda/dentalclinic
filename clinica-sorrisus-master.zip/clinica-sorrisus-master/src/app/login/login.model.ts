export class LoginModel {
    usuario?: string;
    senha?: string;
  }
