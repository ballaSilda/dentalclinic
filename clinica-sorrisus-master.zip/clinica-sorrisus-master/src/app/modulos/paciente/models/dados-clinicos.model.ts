export class DadosClinicosModel {
    convenio?: string;
    alergia?: string;
    sensibilidade?: string;
    medicamento?: string;
    problemaSaude?: string;
    flagAntibiotico?: any;
    flagAnalgesico?: any;
    flagSensibilidade?: any;
    flagPressao?: any;
    flagMedicamento?: any;
    flagProblemaSaude?: any;

}
