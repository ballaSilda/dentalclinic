export class EnderecoModel {
        cep?: string;
        logradouro?: string;
        complemento?: string;
        bairro?: string;
        localidade?: string;
        uf?: string;
        unidade?: string;
        ibge?: number;
        gia?: number;
        numero?: string;
}
