  import { Component, OnInit, Input, ViewChild } from '@angular/core';

  @Component({
    selector: 'app-paciente',
    templateUrl: './paciente.component.html',
    styleUrls: ['paciente.scss']
  })
  export class PacienteComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

  }
