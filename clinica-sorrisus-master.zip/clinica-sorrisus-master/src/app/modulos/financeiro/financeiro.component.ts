import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-financeiro',
  templateUrl: './financeiro.component.html',
  styles: []
})
export class FinanceiroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
