# clínica-sorrisus

## https://luansousa26.github.io/clinica-sorrisus/  :bird:

## Project in progress Angular 5 with Java 8 SPRING BOOT.
Project in progress, for use of dental clinics.

## Login:
### User: admin
### Password: admin

## Technologies:
  * Angular 5.
  * PrimeNg.
  * Angular Material.
  * Java 8.
  * SCSS.
  * HTML5.
  

## Screens:
![login](https://user-images.githubusercontent.com/33549496/39887167-ea9a7cd0-5467-11e8-9023-4a90e54b348c.png)
![image](https://user-images.githubusercontent.com/33549496/43618672-1627cffe-96a0-11e8-8de1-84362046aadb.png)
![image](https://user-images.githubusercontent.com/33549496/43618624-d73ebe24-969f-11e8-8fd5-d7c2edca9d41.png)
![cadastro](https://user-images.githubusercontent.com/33549496/39080177-f71b80de-44ff-11e8-9fea-f4ff6760ecbc.jpg)
![pesquisa](https://user-images.githubusercontent.com/33549496/39080180-f7cf0c1c-44ff-11e8-941b-b313b568a034.jpg)
![grafico_barra](https://user-images.githubusercontent.com/33549496/41756985-a8b70a8a-75b5-11e8-8872-be217762838d.png)
![grafico_pizza](https://user-images.githubusercontent.com/33549496/41756988-b015dbf8-75b5-11e8-8802-0c10110a4dbc.png)
![image](https://user-images.githubusercontent.com/33549496/42143023-4eab4386-7d89-11e8-819e-368e50786c14.png)
![image](https://user-images.githubusercontent.com/33549496/42143052-7932a43c-7d89-11e8-85e2-a4ef86aca67c.png)
![image](https://user-images.githubusercontent.com/33549496/42143084-a0057422-7d89-11e8-995d-400497ddf7fb.png)
